function showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    function hideModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    function showFlashMessage(message, type = 'info') {
        const flashDiv = document.getElementById('flash-messages');
        flashDiv.innerHTML = `<div class="flash-message ${type}">${message}</div>`;
        setTimeout(() => {
            flashDiv.innerHTML = '';
        }, 3000);
    }

    function logout() {
        fetch('/logout', { method: 'POST' })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.removeItem('authToken');
                    updateUI();
                    showFlashMessage('Logged out successfully', 'success');
                }
            });
    }

    function fetchPosts() {
        fetch('/api/posts')
            .then(response => response.json())
            .then(posts => {
                const postsContainer = document.getElementById('posts-container');
                postsContainer.innerHTML = ''; // Clear existing posts
                posts.forEach(post => {
                    const postDiv = document.createElement('div');
                    postDiv.classList.add('post');
                    postDiv.innerHTML = `
                        <div class="post-header">
                            <span class="post-title"><a href="/post/${post.post_hash}">${post.title}</a></span>
                            <span class="post-meta">By ${post.author}, ${post.date}</span>
                        </div>
                        <div class="post-description">${post.description}</div>
                        <div class="post-content">${post.content}</div>
                        <div class="post-footer">
                            <span class="comments-count" id="comments-count-${post.post_hash}" onclick="showComments('${post.post_hash}')">Comments (0)</span>
                            <button class="button" onclick="showModal('commentModal'); document.getElementById('comment-post-hash').value='${post.post_hash}'">Add Comment</button>
                            <button class="button" onclick="showModal('editPostModal${post.post_hash}')" id="edit-post-${post.post_hash}" style="display:none;">Edit Post</button>
                            <button class="button" onclick="deletePost('${post.post_hash}')" id="delete-post-${post.post_hash}" style="display:none;">Delete Post</button>
                        </div>
                        <div class="comments" id="comments-${post.post_hash}"></div>
                    `;
                    postsContainer.appendChild(postDiv);

                    // Fetch and update comments count for each post
                    updateCommentsCount(post.post_hash);

                    // Edit Post Modal
                    const editPostModal = document.createElement('div');
                    editPostModal.id = `editPostModal${post.post_hash}`;
                    editPostModal.classList.add('modal');
                    editPostModal.innerHTML = `
                        <div class="modal-content">
                            <span class="close" onclick="hideModal('editPostModal${post.post_hash}')">&times;</span>
                            <h2>Edit Post</h2>
                            <form id="post-form">
                                <input type="text" name="title" placeholder="Title" required>
                                <textarea name="description" placeholder="Advanced Description (optional)"></textarea>
                                <textarea name="content" placeholder="Content" required></textarea>
                                <input type="file" name="file" class="file-input" accept=".pdf,.doc,.docx,.txt,image/*" max="10485760">
                                <button type="submit" class="button">Create Post</button>
                            </form>
                        </div>
                    `;
                    document.body.appendChild(editPostModal);

                    document.getElementById(`edit-post-form-${post.post_hash}`).addEventListener('submit', function(e) {
                        e.preventDefault();
                        const formData = new FormData(this);
                        fetch(`/edit_post/${post.post_hash}`, {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                showFlashMessage('Post updated successfully', 'success');
                                hideModal(`editPostModal${post.post_hash}`);
                                fetchPosts();
                            } else {
                                showFlashMessage(data.message, 'error');
                            }
                        });
                    });
                });
                updateUI(); // Call updateUI after fetching posts to ensure buttons are displayed correctly
            });
    }

    function updateCommentsCount(postHash) {
        fetch(`/api/comments/${postHash}`)
            .then(response => response.json())
            .then(comments => {
                const commentsCountElement = document.getElementById(`comments-count-${postHash}`);
                if (commentsCountElement) {
                    commentsCountElement.textContent = `Comments (${comments.length})`;
                }
            });
    }

    function showComments(postHash) {
        fetch(`/api/comments/${postHash}`)
            .then(response => response.json())
            .then(comments => {
                const commentsContainer = document.getElementById(`comments-${postHash}`);
                commentsContainer.innerHTML = comments.map(comment => 
                    `<div class="comment">${comment.content} - ${comment.author}, ${comment.date}</div>`
                ).join('');
                updateCommentsCount(postHash);
            });
    }

    function toggleSecretCodeField(select) {
        const secretCodeField = document.getElementById('secret_code_field');
        if (select.value === 'user') {
            secretCodeField.style.display = 'none';
            secretCodeField.required = false;
        } else {
            secretCodeField.style.display = 'block';
            secretCodeField.required = true;
        }
    }

    function deletePost(postHash) {
        fetch(`/delete_post/${postHash}`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showFlashMessage('Post deleted successfully', 'success');
                fetchPosts(); // This will refresh all posts, including comment counts
            } else {
                showFlashMessage(data.message, 'error');
            }
        });
    }

    document.getElementById('login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('/login', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateUI();
                showFlashMessage('Welcome back!', 'success');
                hideModal('loginModal');
            } else {
                showFlashMessage(data.message, 'error');
            }
        });
    });

    document.getElementById('register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('/register', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateUI();
                showFlashMessage('Registration successful!', 'success');
                hideModal('registerModal');
            } else {
                showFlashMessage(data.message, 'error');
            }
        });
    });

    document.getElementById('post-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('/create_post', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showFlashMessage('Post created successfully', 'success');
                hideModal('postModal');
                fetchPosts();
            } else {
                showFlashMessage(data.message, 'error');
            }
        });
    });

    document.getElementById('comment-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const postHash = document.getElementById('comment-post-hash').value;
        hideModal('commentModal'); // Hide the modal immediately
        fetch('/add_comment', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showFlashMessage('Comment added successfully', 'success');
                showComments(postHash); // Show comments after hiding the modal
                fetchPosts(); // Fetch posts again to update the UI
            } else {
                showFlashMessage(data.message, 'error');
            }
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        updateUI();
        fetchPosts();
    });

    function updateUI() {
        fetch('/api/user')
            .then(response => response.json())
            .then(user => {
                if (user) {
                    document.getElementById('login-link').style.display = 'none';
                    document.getElementById('register-link').style.display = 'none';
                    document.getElementById('new-post-link').style.display = 'inline';
                    document.getElementById('logout-link').style.display = 'inline';
                    document.getElementById('user-stats').style.display = 'block';
                    fetchUserStats();

                    if (user.role === 'admin') {
                        document.getElementById('admin-panel').style.display = 'block';
                        fetchUsersForAdmin();
                    }

                    // Show edit and delete buttons for admin and moderator
                    if (user.role === 'admin' || user.role === 'moderator') {
                        document.querySelectorAll('.post').forEach(post => {
                            const postHash = post.querySelector('.post-title a').getAttribute('href').split('/').pop();
                            const editButton = document.getElementById(`edit-post-${postHash}`);
                            const deleteButton = document.getElementById(`delete-post-${postHash}`);
                            if (editButton) editButton.style.display = 'inline';
                            if (deleteButton) deleteButton.style.display = 'inline';
                        });
                    }
                } else {
                    document.getElementById('login-link').style.display = 'inline';
                    document.getElementById('register-link').style.display = 'inline';
                    document.getElementById('new-post-link').style.display = 'none';
                    document.getElementById('logout-link').style.display = 'none';
                    document.getElementById('user-stats').style.display = 'none';
                    document.getElementById('admin-panel').style.display = 'none';
                }
            });
    }

    function fetchUserStats() {
        fetch('/api/user_stats')
            .then(response => response.json())
            .then(data => {
                if (data.success === false) {
                    document.getElementById('user-stats').style.display = 'none';
                } else {
                    document.getElementById('post-count').textContent = data.post_count;
                    document.getElementById('join-date').textContent = data.join_date;
                }
            });
    }

    function fetchUsersForAdmin() {
        fetch('/admin/users')
            .then(response => response.json())
            .then(data => {
                const userList = document.getElementById('user-list');
                userList.innerHTML = '';
                data.users.forEach(user => {
                    const li = document.createElement('li');
                    li.textContent = `${user.username} - Role: ${user.role}`;
                    const deleteButton = document.createElement('button');
                    deleteButton.textContent = 'Delete';
                    deleteButton.onclick = () => deleteUser(user.id);
                    li.appendChild(deleteButton);
                    userList.appendChild(li);
                });
            });
    }

    function deleteUser(userId) {
        fetch(`/admin/delete_user/${userId}`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                fetchUsersForAdmin();
            }
        });
    }