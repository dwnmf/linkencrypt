import secrets
import json

def generate_secret_code():
    return secrets.token_hex(16)  # Generates a 32-character hexadecimal secret code

def save_secret_codes(filename='secret_codes.json'):
    secret_codes = {
        'moderator': generate_secret_code(),
        'admin': generate_secret_code()
    }
    with open(filename, 'w') as f:
        json.dump(secret_codes, f)

if __name__ == '__main__':
    save_secret_codes()